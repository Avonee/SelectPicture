//
//  ViewController.swift
//  SelectPicture
//
//  Created by Ya Fang Cheng on 2016/11/7.
//  Copyright © 2016年 Ya Fang Cheng. All rights reserved.
//

import UIKit



class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var BigHead: UIImageView!
    var imagePicker:UIImagePickerController!
   
    
   
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        
    }
   

    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //拿相片按鈕
    @IBAction func openPhotoLibrary(sender: AnyObject) {
        imagePicker = UIImagePickerController()
        imagePicker.modalPresentationStyle = .currentContext
        
        imagePicker.sourceType = .photoLibrary
        
        imagePicker.delegate = self
        present(imagePicker, animated: true, completion: nil)
    }
    
    //拿相片頁面
     func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage{
            BigHead.image = image
           
        }
        imagePicker.dismiss(animated: true, completion: nil)
        
    }
    
    
    
    
    
}


